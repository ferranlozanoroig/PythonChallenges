# Escribir un programa que pregunte al usuario su edad y
# muestre por pantalla si es mayor de edad o no.

age = int(input("¿Cuál es tu edad? "))

if age >= 18:
    print("Eres mayor de edad")
else:
    print("Eres menor de edad")